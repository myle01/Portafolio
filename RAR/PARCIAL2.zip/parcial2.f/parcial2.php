<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: inicio.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Checklist Tracker</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Check list Tracker</h1>
      <h2>Crear nueva tarea</h2>
      <p>Bienvenido, <?php echo $_SESSION['username']; ?> 
      <button type="button" onclick="window.location.href='cerrar.php'">Cerrar Sesión</button>

      <form action="guardar.php" method="post">
        <label for="titulo">Título:</label>
        <input type="text" id="titulo" name="titulo" required><br><br>
        <label for="descripcion">Descripción:</label>
        <textarea id="descripcion" name="descripcion" rows="5"></textarea><br><br>
        <label for="estado">Estado:</label>
        <select id="estado" name="estado"><br><br>
          <option value="por_hacer">Por hacer</option>
          <option value="en_progreso">En progreso</option>
          <option value="terminada">Terminada</option>
        </select><br><br>
        <label for="fecha_compromiso">Fecha de compromiso:</label>
        <input type="date" id="fecha_compromiso" name="fecha_compromiso"><br><br>
        <label for="responsable">Responsable:</label>
        <input type="text" id="responsable" name="responsable"><br><br>
        <label for="tipo_tarea">Tipo de tarea:</label>
        <input type="text" id="tipo_tarea" name="tipo_tarea"><br><br>
        <button type="submit">Guardar</button>
        <button type="button" onclick="window.location.href='mostrar.php'">Mostrar</button>
        <button type="button" onclick="window.location.href='reporte.php'">Reporte</button>
      </form>
</body>
</html>
