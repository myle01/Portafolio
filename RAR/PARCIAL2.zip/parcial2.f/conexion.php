<?php
$conn = new mysqli('localhost', 'root', '', 'check_list');
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>