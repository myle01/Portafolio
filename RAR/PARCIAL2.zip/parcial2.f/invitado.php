<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Checklist Tracker</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Check list Tracker</h1>
      <h2>Crear nueva tarea</h2>
      <form action="guardar.php" method="post">
        <label for="titulo">Título:</label>
        <input type="text" id="titulo" name="titulo" required><br><br>
        <label for="descripcion">Descripción:</label>
        <textarea id="descripcion" name="descripcion" rows="5"></textarea><br><br>
        <label for="estado">Estado:</label>
        <select id="estado" name="estado">
          <option value="por_hacer">Por hacer</option>
          <option value="en_progreso">En progreso</option>
          <option value="terminada">Terminada</option>
        </select><br><br>
        <label for="fecha_compromiso">Fecha de compromiso:</label>
        <input type="date" id="fecha_compromiso" name="fecha_compromiso"><br><br>
        <label for="responsable">Responsable:</label>
        <input type="text" id="responsable" name="responsable"><br><br>
        <label for="tipo_tarea">Tipo de tarea:</label>
        <input type="text" id="tipo_tarea" name="tipo_tarea"><br><br>
        <button type="submit">Guardar</button>
        <button type="button" onclick="window.location.href='mostrar_invitado.php'">Mostrar</button>
        <button onclick="window.location.href='parcial2.php'">Cerrar Modo Invitado</button>
      </form>
</body>
</html>