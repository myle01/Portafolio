<?php include('conexion.php'); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte de Tareas</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Reporte de Tareas</h1>
    
    <h2>Reporte por Tipo de Tarea</h2>
    <?php
    $result = $conn->query("SELECT tipo_tarea, COUNT(*) as total FROM check_list GROUP BY tipo_tarea");
    while ($row = $result->fetch_assoc()) {
        echo "<p>" . $row['tipo_tarea'] . ": " . $row['total'] . " tareas</p>";
    }
    ?>

    <h2>Reporte por Estado</h2>
    <?php
    $result = $conn->query("SELECT estado, COUNT(*) as total FROM check_list GROUP BY estado");
    while ($row = $result->fetch_assoc()) {
        echo "<p>" . $row['estado'] . ": " . $row['total'] . " tareas</p>";
    }
    ?>

    <h2>Reporte por Día</h2>
    <?php
    $result = $conn->query("SELECT DATE(fecha_compromiso) as dia, COUNT(*) as total FROM check_list GROUP BY DATE(fecha_compromiso)");
    while ($row = $result->fetch_assoc()) {
        echo "<p>" . $row['dia'] . ": " . $row['total'] . " tareas</p>";
    }
    ?>

    <h2>Reporte por Semana</h2>
    <?php
    $result = $conn->query("SELECT YEARWEEK(fecha_compromiso, 1) as semana, COUNT(*) as total FROM check_list GROUP BY YEARWEEK(fecha_compromiso, 1)");
    while ($row = $result->fetch_assoc()) {
        echo "<p>Semana " . $row['semana'] . ": " . $row['total'] . " tareas</p>";
    }
    ?>

    <h2>Reporte por Mes</h2>
    <?php
    $result = $conn->query("SELECT DATE_FORMAT(fecha_compromiso, '%Y-%m') as mes, COUNT(*) as total FROM check_list GROUP BY DATE_FORMAT(fecha_compromiso, '%Y-%m')");
    while ($row = $result->fetch_assoc()) {
        echo "<p>" . $row['mes'] . ": " . $row['total'] . " tareas</p>";
    }
    ?>

    <h2>Reporte por Año</h2>
    <?php
    $result = $conn->query("SELECT YEAR(fecha_compromiso) as ano, COUNT(*) as total FROM check_list GROUP BY YEAR(fecha_compromiso)");
    while ($row = $result->fetch_assoc()) {
        echo "<p>" . $row['ano'] . ": " . $row['total'] . " tareas</p>";
    }
    ?>

    <button type="button" onclick="window.location.href='parcial2.php'">Volver a la página de inicio</button>

</body>
</html>
