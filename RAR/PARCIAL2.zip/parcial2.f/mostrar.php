<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mostrar Lista de Tareas</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="table">
    <h1>Lista de Tareas</h1>
    <?php
    include 'conexion.php';
    $sql = "SELECT * FROM check_list";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        echo "<table><tr><th>ID</th><th>Titulo</th></th><th>Descripcion</th></th><th>Estado</th></th><th>Fecha de compromiso</th></th><th>Responsable</th></th><th>Tipo de Tarea</th></tr>";
        while($row = $result->fetch_assoc()) {
            echo "<tr><td>".$row["id"]."</td><td>".$row["titulo"]."</td><td>".$row["descripcion"]."</td><td>".$row["estado"]."</td><th>".$row["fecha_compromiso"]."</td><th>".$row["responsable"]."</td><td>".$row["tipo_tarea"]."</td>";
            echo "<td><a href='actualizar.php?id=".$row["id"]."'>Actualizar</a> | <a href='eliminar.php?id=".$row["id"]."'>Eliminar</a></td></tr></tr>";
        }
        echo "</table>";
    } else {
        echo "0 resultados";
    }
    $conn->close();
    ?>
    </div><br><br>
    <button onclick="window.location.href='parcial2.php'">Volver</button>
</body>
</html>