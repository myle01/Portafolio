<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Guardar Tarea</title>
    <link rel="stylesheet" href="styles.css">
    <div class=guardar>
    </div>
</head>
    </html>

<?php
include('conexion.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $titulo = $_POST['titulo'];
    $descripcion = $_POST['descripcion'];
    $estado = $_POST['estado'];
    $fecha_compromiso = $_POST['fecha_compromiso'];
    $responsable = $_POST['responsable'];
    $tipo_tarea = $_POST['tipo_tarea'];

    $sql = "INSERT INTO  check_list (titulo, descripcion, estado, fecha_compromiso, responsable, tipo_tarea)
            VALUES ('$titulo', '$descripcion', '$estado', '$fecha_compromiso', '$responsable', '$tipo_tarea')";

    if ($conn->query($sql) === TRUE) {
        echo "Tarea guardada exitosamente";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?><br>
<button onclick="window.location.href='parcial2.php'">Volver a la página principal</button>
