<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Actualizar Estudiante</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Actualizar Lista de Tareas</h1>
    <?php
    include 'conexion.php';
    if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
        $id = $_GET['id'];
        $sql = "SELECT * FROM check_list WHERE id=$id";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            echo "<form action='actualizar.php' method='POST'>";
            echo "<input type='hidden' name='id' value='".$row['id']."'><br>";
            echo "<label for='titulo'>Titulo:</label>";
            echo "<input type='text' id='titulo' name='titulo' value='".$row['titulo']."' required><br><br>";
            echo "<label for='descripcion'>Descripcion:</label>";
            echo "<input type='text' id='descripcion' name='descripcion' value='".$row['descripcion']."' required><br><br>";
            echo "<label for='estado'>Estado:</label>";
            echo "<input type='text' id='estado' name='estado' value='".$row['estado']."' required><br><br>";
            echo "<label for='fecha_compromiso'>Fecha de Compromiso:</label>";
            echo "<select id='estado'name='estado'>";         
            echo "<option value='por_hacer'>Por hacer</option>";
            echo "<option value='en_progreso'>En progreso</option>";
            echo "<option value='terminada'>Terminada</option>";
            echo "</select><br>";
            echo "<input type='text' id='fecha_compromiso'name='fecha_compromiso' value='".$row['fecha_compromiso']."' required><br><br>";
            echo "<label for='Responsable'>Responsable:</label>";
            echo "<input type='text' id='responsable' name='responsable' value='".$row['responsable']."' required><br><br>";
            echo "<label for='tipo_tarea'>Tipo de Tarea</label>";
            echo "<input type='text' id='tipo_tarea' name='tipo_tarea'value='".$row['tipo_tarea']."'required><br><br>"; 
            echo "<button type='submit'>Guardar</button>";
            echo "</form>";
        } else {
            echo "Tarea no encontrado";
        }
    } elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $id = $_POST['id'];
        $titulo= $_POST['titulo'];
        $descripcion = $_POST['descripcion'];
        $estado = $_POST['estado'];
        $fecha_compromiso = $_POST['fecha_compromiso'];
        $responsable = $_POST['responsable'];
        $tipo_tarea = $_POST['tipo_tarea'];
        $sql = "UPDATE check_list SET titulo='$titulo', descripcion='$descripcion', estado='$estado', fecha_compromiso='$fecha_compromiso', responsable='$responsable', tipo_tarea='$tipo_tarea' WHERE id='$id'";
        if ($conn->query($sql) === TRUE) {
            echo "Tarea actualizada exitosamente";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
        $conn->close();
    }
    ?><br><br>
    <button onclick="window.location.href='mostrar.php'">Volver</button>
</body>
</html>