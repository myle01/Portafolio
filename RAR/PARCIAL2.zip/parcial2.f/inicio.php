<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset ="UTF-8">
        <title>Inicio de Sesión</title>
        <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
<h1>Inicio de Sesión</h1>
</div>
<form action="inicio.php" method="POST";=>
    <label for=username>Nombre de Usuario:</label>
    <input type="text" id="username" name="username" required><br><br>
    <label for=password>Contraseña:</label>
    <input type="password" id="password" name="password" required><br><br>
    <button type="submit">Iniciar Sesion</button>
    <button type="button" onclick="window.location.href='registro.php'">Crear Usuario</button>
    <button onclick="window.location.href='invitado.php'">Modo Invitado</button>
</form>
</body>
</html>
<?php   
session_start( );
include 'conexion.php';
if($_SERVER['REQUEST_METHOD']=='POST'){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $sql ="SELECT * FROM usuarios WHERE username= '$username'";
    $result= $conn->query($sql);
    if($result ->num_rows >0) {
        $row = $result->fetch_assoc();
        if(password_verify($password, $row['password'])){
            $_SESSION['username']= $username;
            header('location: parcial2.php');
        } else{
            echo" contraseña incorrecta";
        }
    }else {
        echo "usuario no encontrado ";
    }
    $conn->close();
}
?>