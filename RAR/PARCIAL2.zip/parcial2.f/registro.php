<!DOCTYPE html>
<html lang ="es">
    <head>
        <meta charset="UTF-8">
        <title>Registro de Usuario</title>
        <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Registro de Usuario</h1>
    <form action="registro.php" method="POST";=>
    <label for=username>Nombre de Usuario:</label>
    <input type="text" id="username" name="username" required><br><br>
    <label for=password>Contraseña:</label>
    <input type="password" id="password" name="password" required><br><br>
    <button type="submit">Registrar</button>
    <button onclick="window.location.href='inicio.php'">Iniciar Sesion</button>
    <button onclick="window.location.href='insertar.php'">Modo Invitado</button>
</form>
</body>
</html>
<?php
include 'conexion.php';
if($_SERVER['REQUEST_METHOD']== 'POST'){
    $username=$_POST['username'];
    $password=password_hash($_POST['password'], PASSWORD_BCRYPT);
    $sql = "INSERT INTO usuarios(username, password) VALUES('$username','$password')";
    if($conn->query($sql) === TRUE){
        echo "Registro exitoso";
    } else{
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
}
?>
