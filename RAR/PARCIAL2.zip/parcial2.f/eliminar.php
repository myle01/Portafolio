<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Eliminar</title>
    <link rel="stylesheet" href="styles.css">
    <div class=eliminar>
    </div>
    <h1>Eliminar Lista de Tareas</h1>
</head>
    </html>
<?php
include 'conexion.php';
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM check_list WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        echo "Tarea eliminada exitosamente";
    } else {
        echo "Error: " . $conn->error;
    }
} else {
    echo "ID no proporcionado";
}
$conn->close();
?><br><br>
<button onclick="window.location.href='mostrar.php'">Volver</button>