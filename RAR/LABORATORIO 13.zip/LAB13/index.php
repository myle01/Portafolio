<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Inicio</title>
    <link rel="stylesheet" href="styles.css"> </head>
<body> 
        <h1>Bienvenido</h1>
        <button><a href="registro.php">Registrarse</a></button>
        <button><a href="login.php">Iniciar Sesión</a></button>
</body>
</html>